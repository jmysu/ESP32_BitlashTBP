#include <Arduino.h>
extern void setupTinyBasicPlus();
extern void loopTinyBasicPlus();